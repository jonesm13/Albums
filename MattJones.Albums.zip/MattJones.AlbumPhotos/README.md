
# Album-Photos solution

Here is my solution to the coding test.

Points to note:

1. I've followed the "Ports and Adapters" convention, which is essentially just substitution
by interface implementation. Interfaces have role-based names describing the "what"-ness of
what they do, while concrete class names suggest *how* the interface contract is met. The
controller method that exposes the albums is not bound to any particular implementation of
the `AlbumProvider` and can easily be replaced by changing the IoC bindings in `Startup`.

2. The tests seem sparse, however I have deliberately not 'tested all the things'. Although
it may be tempting to use mocks (a library such as `Moq`) to verify that all the dependencies
are calling each other, I believe that this breaks the constraint of unit tests not knowing
or caring about implementations internal to the classes they test. Just verifying Mocks brings
about brittle tests and ultimatly the disadvantage of making refactoring painful. I have
restricted the tests to two tests that exercise the combiner/mapper and two that call the
main API itself.

// TODO

1. The code that maps the Dto types to the public model (c.f. `CombinationExtensions`)
is ugly and looks clunky. This could be more elegantly addressed using a library such
as AutoMapper to handle the boilerplate mapping from Dtos to more complex models and
back again. However the scope of the method is contained and it's nicely tucked away
inside an extension method, which makes using the method much more literate.

2. `HttpJsonAlbumPhotoClient` breaks SOLID because it is responsible for returning both album
AND photo data from an HttpJson source. However, given that it makes no sense to request these
two resources from two different base urls this is OK for the moment. I accepted this piece
of technical debt with a note to change it should other sources of data be required.
