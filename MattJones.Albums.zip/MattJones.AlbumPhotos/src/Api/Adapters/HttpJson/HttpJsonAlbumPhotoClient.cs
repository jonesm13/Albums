﻿namespace Api.Adapters.HttpJson
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Threading.Tasks;
    using Dto;
    using Ports;
    using Newtonsoft.Json;

    public class HttpJsonAlbumPhotoClient : IFetchAlbumPhotoData, IDisposable
    {
        readonly HttpClient client;

        public HttpJsonAlbumPhotoClient(string baseUri)
        {
            client = new HttpClient
            {
                BaseAddress = new Uri(baseUri)
            };
        }

        public Task<IEnumerable<PhotoDto>> GetPhotosAsync()
        {
            return GetAsync<IEnumerable<PhotoDto>>("photos");
        }

        public Task<IEnumerable<AlbumDto>> GetAlbumsAsync()
        {
            return GetAsync<IEnumerable<AlbumDto>>("albums");
        }

        async Task<T> GetAsync<T>(string queryUrl)
        {
            string json = await client.GetStringAsync(queryUrl);
            return JsonConvert.DeserializeObject<T>(json);
        }

        public void Dispose()
        {
            client?.Dispose();
        }
    }
}