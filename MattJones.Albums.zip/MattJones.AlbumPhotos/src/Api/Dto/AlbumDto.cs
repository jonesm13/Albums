﻿namespace Api.Dto
{
    public class AlbumDto
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string Title { get; set; }
    }
}