﻿namespace Api.Services
{
    using Dto;
    using Extensions;
    using Models;
    using Ports;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class MappingCombiningProvider : IProvideAlbums
    {
        readonly IFetchAlbumPhotoData dataSource;

        public MappingCombiningProvider(IFetchAlbumPhotoData dataSource)
        {
            this.dataSource = dataSource;
        }

        public async Task<IEnumerable<Album>> GetAsync(
            int? userId = default(int?))
        {
            IEnumerable<AlbumDto> albums = await dataSource.GetAlbumsAsync();

            List<AlbumDto> albumsList = albums.ToList();

            if (!albumsList.Any())
            {
                return Enumerable.Empty<Album>();
            }

            IEnumerable<PhotoDto> photos = await dataSource.GetPhotosAsync();

            return albumsList.CombineWith(photos).FilterBy(userId);
        }
    }
}
