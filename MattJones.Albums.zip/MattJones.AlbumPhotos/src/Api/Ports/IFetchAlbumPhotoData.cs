﻿namespace Api.Ports
{
    using System.Threading.Tasks;
    using System.Collections.Generic;
    using Dto;

    public interface IFetchAlbumPhotoData
    {
        Task<IEnumerable<PhotoDto>> GetPhotosAsync();

        Task<IEnumerable<AlbumDto>> GetAlbumsAsync();
    }
}