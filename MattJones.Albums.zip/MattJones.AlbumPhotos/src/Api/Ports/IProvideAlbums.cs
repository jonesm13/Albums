﻿namespace Api.Ports
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Models;

    public interface IProvideAlbums
    {
        Task<IEnumerable<Album>> GetAsync(int? userId = default(int?));
    }
}
