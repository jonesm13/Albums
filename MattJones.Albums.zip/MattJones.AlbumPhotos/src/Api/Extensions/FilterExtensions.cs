﻿namespace Api.Extensions
{
    using System.Collections.Generic;
    using System.Linq;
    using Models;

    public static class FilterExtensions
    {
        public static IEnumerable<Album> FilterBy(
            this IEnumerable<Album> albums,
            int? userId = default(int?))
        {
            return albums.Where(x => !userId.HasValue ||
                                     userId.Value == x.UserId);
        }
    }
}