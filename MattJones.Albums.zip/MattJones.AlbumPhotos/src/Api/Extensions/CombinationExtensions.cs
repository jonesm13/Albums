﻿namespace Api.Extensions
{
    using System.Collections.Generic;
    using System.Linq;
    using Dto;
    using Models;

    public static class CombinationExtensions
    {
        public static IEnumerable<Album> CombineWith(
            this IEnumerable<AlbumDto> albumDtos,
            IEnumerable<PhotoDto> photoDtos)
        {
            IEnumerable<Album> result = albumDtos.GroupJoin(
                photoDtos,
                album => album.Id,
                photo => photo.AlbumId,
                (a, p) => new Album
                {
                    Id = a.Id,
                    Title = a.Title,
                    UserId = a.UserId,
                    Photos = p.Select(x => new Photo
                    {
                        Id = x.Id,
                        Title = x.Title,
                        ThumbnailUrl = x.ThumbnailUrl,
                        Url = x.Url
                    })
                    .ToList()
                });

            return result;
        }
    }
}
