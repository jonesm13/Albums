﻿namespace Api.Controllers
{
    using Models;
    using Ports;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;

    [Route("api/album-photos")]
    [ApiController]
    public class AlbumPhotosController : ControllerBase
    {
        readonly IProvideAlbums provider;

        public AlbumPhotosController(IProvideAlbums provider)
        {
            this.provider = provider;
        }

        [HttpGet("")]
        public async Task<IEnumerable<Album>> Get(
            int? userId = default(int?))
        {
            return await provider.GetAsync();
        }

        [HttpGet("users/{userId:int}")]
        public async Task<IEnumerable<Album>> GetByUser(
            int? userId = default(int?))
        {
            return await provider.GetAsync(userId);
        }
    }
}
