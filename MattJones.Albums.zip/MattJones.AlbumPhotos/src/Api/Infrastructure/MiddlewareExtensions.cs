﻿namespace Api.Infrastructure
{
    using System;
    using System.Net;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Http;

    public static class MiddlewareExtensions
    {
        public static void UseExceptionHandling(this IApplicationBuilder app)
        {
            app.Use(async (context, next) =>
            {
                try
                {
                    await next();
                }
                catch(Exception)
                {
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    context.Response.ContentType = "application/json";

                    await context.Response.WriteAsync(
                        "{ \"message\" : \"An internal server error occurred\" }");
                }
            });
        }
    }
}