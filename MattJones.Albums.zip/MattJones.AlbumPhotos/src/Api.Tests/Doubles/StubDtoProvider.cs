using System.Collections.Generic;
using System.Threading.Tasks;
using Api.Dto;
using Api.Ports;

namespace Api.Tests.Doubles
{
    public class StubDtoProvider : IFetchAlbumPhotoData
    {
        private readonly IEnumerable<AlbumDto> _albums;
        private readonly IEnumerable<PhotoDto> _photos;

        public StubDtoProvider(
            IEnumerable<AlbumDto> albums,
            IEnumerable<PhotoDto> photos)
        {
            _albums = albums;
            _photos = photos;
        }

        public Task<IEnumerable<PhotoDto>> GetPhotosAsync()
        {
            return Task.FromResult(_photos);
        }

        public Task<IEnumerable<AlbumDto>> GetAlbumsAsync()
        {
            return Task.FromResult(_albums);
        }
    }
}