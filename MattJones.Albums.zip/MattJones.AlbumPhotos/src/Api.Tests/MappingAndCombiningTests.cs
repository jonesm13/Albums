namespace Api.Tests
{
    using Doubles;
    using Dto;
    using Models;
    using NUnit.Framework;
    using Services;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class MappingAndCombiningTests
    {
        [Test]
        public async Task EmptyInputReturnsEmptyResult()
        {
            // arrange
            StubDtoProvider provider = Build.Empty;
            MappingCombiningProvider sut = new MappingCombiningProvider(provider);

            // act
            IEnumerable<Album> actual = await sut.GetAsync();

            // assert
            List<Album> actualList = actual.ToList();

            Assert.AreEqual(0, actualList.Count);
        }

        [Test]
        public async Task OneAlbumMappedToResultWithOneMemberAndNoChildPhotos()
        {
            StubDtoProvider provider = Build.SingleAlbumNoPhotos;
            MappingCombiningProvider sut = new MappingCombiningProvider(provider);

            IEnumerable<Album> actual = await sut.GetAsync();

            List<Album> actualList = actual.ToList();

            Assert.AreEqual(1, actualList.Count);
            Assert.AreEqual(0, actualList.First().Photos.Count());
        }

        [Test]
        public async Task OneAlbumWithOnePhotoMappedToOneResult()
        {
            StubDtoProvider provider = Build.OneAlbumOnePhoto;
            MappingCombiningProvider sut = new MappingCombiningProvider(provider);

            IEnumerable<Album> actual = await sut.GetAsync();

            List<Album> actualList = actual.ToList();

            Assert.AreEqual(1, actualList.Count);
            Assert.AreEqual(1, actualList.First().Photos.Count());
        }

        [Test]
        public async Task ManyAlbumsAndChildPhotosMappedToAlbums()
        {
            StubDtoProvider provider = Build.MultipleAlbumsAndPhotos;
            MappingCombiningProvider sut = new MappingCombiningProvider(provider);

            IEnumerable<Album> actual = await sut.GetAsync();

            List<Album> actualList = actual.ToList();

            Assert.AreEqual(5, actualList.Count);
            Assert.IsTrue(actualList.All(x => x.Photos.Count() == 2));
        }
        
        #region Test fixture builders

        static class Build
        {
            public static StubDtoProvider Empty => new StubDtoProvider(
                new List<AlbumDto>(),
                new List<PhotoDto>());

            public static StubDtoProvider SingleAlbumNoPhotos => new StubDtoProvider(
                new List<AlbumDto>
                {
                    new AlbumDto { Id = 1, Title = "Album 1", UserId = 1 }
                },
                new List<PhotoDto>());

            public static StubDtoProvider OneAlbumOnePhoto => new StubDtoProvider(
                new List<AlbumDto>
                {
                    new AlbumDto
                    {
                        Id = 1,
                        Title = "Album 1",
                        UserId = 1
                    }
                },
                new List<PhotoDto>
                {
                    new PhotoDto
                    {
                        AlbumId = 1,
                        Title = "Title",
                        ThumbnailUrl = "http://some.img/1-thumb.png",
                        Id = 1,
                        Url = "http://some.img/1.png"
                    }
                });
            
            public static StubDtoProvider MultipleAlbumsAndPhotos => new StubDtoProvider(
                new List<AlbumDto>
                {
                    new AlbumDto { Id = 1, Title = "Title 1", UserId = 1 },
                    new AlbumDto { Id = 2, Title = "Title 2", UserId = 2 },
                    new AlbumDto { Id = 3, Title = "Title 3", UserId = 2 },
                    new AlbumDto { Id = 4, Title = "Title 4", UserId = 3 },
                    new AlbumDto { Id = 5, Title = "Title 5", UserId = 3 }
                },
                new List<PhotoDto>
                {
                    new PhotoDto { Id = 1, Title = "Photo 1", AlbumId = 1 },
                    new PhotoDto { Id = 2, Title = "Photo 2", AlbumId = 1 },
                    new PhotoDto { Id = 3, Title = "Photo 3", AlbumId = 2 },
                    new PhotoDto { Id = 4, Title = "Photo 4", AlbumId = 2 },
                    new PhotoDto { Id = 5, Title = "Photo 5", AlbumId = 3 },
                    new PhotoDto { Id = 6, Title = "Photo 6", AlbumId = 3 },
                    new PhotoDto { Id = 7, Title = "Photo 7", AlbumId = 4 },
                    new PhotoDto { Id = 8, Title = "Photo 8", AlbumId = 4 },
                    new PhotoDto { Id = 9, Title = "Photo 9", AlbumId = 5 },
                    new PhotoDto { Id = 10, Title = "Photo 10", AlbumId = 5 },
                }
            );
        }

        #endregion
    }
}