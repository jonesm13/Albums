namespace Api.Tests
{
    using Doubles;
    using Dto;
    using Models;
    using NUnit.Framework;
    using Services;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class FilteringTests
    {
        [Test]
        public async Task CanFilterByUserId()
        {
            MappingCombiningProvider sut = new MappingCombiningProvider(Build.Case);

            IEnumerable<Album> actual = await sut.GetAsync(1);

            Assert.AreEqual(3, actual.Count());
        }

        #region Test fixture builders

        internal static class Build
        {
            public static StubDtoProvider Case => new StubDtoProvider(
                new List<AlbumDto>
                {
                    new AlbumDto { Id = 1, Title = "Title 1", UserId = 1 },
                    new AlbumDto { Id = 2, Title = "Title 2", UserId = 1 },
                    new AlbumDto { Id = 3, Title = "Title 3", UserId = 1 },
                    new AlbumDto { Id = 4, Title = "Title 4", UserId = 2 },
                    new AlbumDto { Id = 5, Title = "Title 5", UserId = 3 },
                },
                new List<PhotoDto>());
        }

        #endregion
    }
}